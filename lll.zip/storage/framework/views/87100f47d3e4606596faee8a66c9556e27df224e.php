<?php $__env->startSection('content'); ?>
    <h1 class="uk-text-center">Students</h1>
<div uk-scrollspy="cls: uk-animation-fade; repeat: false" class="uk-overlay uk-overlay-primary uk-width-auto">
   <table class="uk-table uk-table-divider">
      <thead>
         <tr>
         	<th>No</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Type</th>
            <th>Action</th>
         </tr>
      </thead>
      <tbody>
         <?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$study): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr>
            <td><?php echo e($student->firstItem()+ $key); ?></td>
            <td><?php echo e($study->name); ?></td>
            <td><?php echo e($study->email); ?></td>
            <td><?php echo e($study->phone); ?></td>
            <td><?php echo e($study->type); ?></td>
            <td>
               <a class="uk-button uk-button-text uk-text-primary" href="<?php echo e(route('update.student',$study)); ?>">Update</a>
               <form action="<?php echo e(route('student.destroy', $study)); ?>" method="post">
                  <?php echo e(csrf_field()); ?>

                  <?php echo e(method_field('DELETE')); ?>

                  <button class="uk-button uk-button-text uk-text-danger" > Delete </button>
               </form>
            </td>
         </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
   </table>
       <?php echo $student->render(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>