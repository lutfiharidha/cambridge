<?php $__env->startSection('content'); ?>
<h1 class="uk-text-center">Orders</h1>
<div uk-scrollspy="cls: uk-animation-fade; repeat: false" class="uk-overlay uk-overlay-primary uk-width-auto">
   <table class="uk-table uk-table-divider">
      <thead>
         <tr>
            <th>No</th>
            <th>Name</th>
            <th>Address</th>
            <th>Phone Number</th>
            <th>WhatsApp</th>
            <th>Package</th>
         </tr>
      </thead>
      <tbody>
         <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr>
            <td><?php echo e($orders->firstItem()+ $key); ?></td>
            <td><?php echo e($order->name); ?></td>
            <td><?php echo e($order->address); ?></td>
            <td><?php echo e($order->telp); ?></td>
            <td><a href="https://api.whatsapp.com/send?phone=<?php echo e($order->whatsapp); ?>&text=assalamu'alaikum,apakah benar anda memesan <?php echo e($order->get_package->name); ?> pada web kami?" target="_blank"><?php echo e($order->whatsapp); ?></a></td>
            <td><?php echo e($order->get_package->name); ?></td>
         </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
   </table>
   <?php echo $orders->render(); ?>

</div>
<?php if(session()->has('message')): ?>
<div class="uk-text-center uk-text-lead" uk-alert>
   <a class="uk-alert-close" uk-close></a>
   <h3>Notice</h3>
   <p><?php echo e(session()->get('message')); ?></p>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>