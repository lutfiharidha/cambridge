<?php $__env->startSection('content'); ?>
<main class="uk-padding uk-container uk-container-large">
	<div>
	<img class="uk-align-center" src="http://frugalz.com/assets/front/images/404.png">
	</div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navb', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>