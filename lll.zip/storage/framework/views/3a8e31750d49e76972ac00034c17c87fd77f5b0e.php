<?php $__env->startSection('content'); ?>
<div class="uk-container uk-container-medium uk-card uk-card-secondary" uk-scrollspy="cls: uk-animation-fade; repeat: true">
   <form class="uk-padding " action="<?php echo e(route('update.class',$class)); ?>"  enctype="multipart/form-data" method="post">
      <fieldset class=" uk-margin-top uk-fieldset">
         <?php echo e(csrf_field()); ?>

         <legend class="uk-legend ">Edit Class</legend>
         Class
         <div class="uk-margin">
            <input class="uk-input" type="text" name="name" value="<?php echo e($class->name); ?>" required>
         </div>
      </fieldset>
      <div class="uk-margin">
         <input  class="uk-button uk-button-default" type="submit" placeholder="Post">
      </div>
   </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>