<?php $__env->startSection('content'); ?>
    <h1 class="uk-text-center">Teachers</h1>
<div uk-scrollspy="cls: uk-animation-fade; repeat: false" class="uk-overlay uk-overlay-primary uk-width-auto">
   <table class="uk-table uk-table-divider">
      <thead>
         <tr>
         	<th>No</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Action</th>
         </tr>
      </thead>
      <tbody>
         <?php $__currentLoopData = $teacher; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$teach): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr>
            <td><?php echo e($teacher->firstItem()+ $key); ?></td>
            <td><?php echo e($teach->name); ?></td>
            <td><?php echo e($teach->email); ?></td>
            <td><?php echo e($teach->phone); ?></td>
            <td>
               <a class="uk-button uk-button-text uk-text-primary" href="<?php echo e(route('update.teacher',$teach)); ?>">Update</a>
               <form action="<?php echo e(route('teacher.destroy', $teach)); ?>" method="post">
                  <?php echo e(csrf_field()); ?>

                  <?php echo e(method_field('DELETE')); ?>

                   <button class="uk-button uk-button-text uk-text-danger" onclick="return confirm('Are you sure to delete <?php echo e($teach->name); ?>?')" > Delete </button>
               </form>
            </td>
         </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
   </table>
       <?php echo $teacher->render(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>