<?php $__env->startSection('content'); ?>
<div class="uk-container uk-container-medium uk-card uk-card-secondary" uk-scrollspy="cls: uk-animation-fade; repeat: true">
<form class="uk-padding " action="<?php echo e(route('storepackage')); ?>"  enctype="multipart/form-data" method="post">
   <fieldset class=" uk-margin-top uk-fieldset">
      <?php echo e(csrf_field()); ?>

      <legend class="uk-legend ">Add Package</legend>
      Name
      <div class="uk-margin">
         <input class="uk-input" type="text" name="name" placeholder="Name Package">
      </div>
      Description
      <div class="uk-margin">
         <textarea class="uk-textarea ckeditor" id="ckedtor" name="description" rows="5"></textarea>
      </div>
      Price
      <div class="uk-margin">
         <input class="uk-input" type="number" name="price" placeholder="Price">
      </div>
      <div class="uk-margin">
         <div class="uk-form-controls">
            <select class="uk-select" id="form-stacked-select" name="until">
               <option value="Week">Week</option>
               <option value="Month">Month</option>
               <option value="Year">Year</option>
            </select>
         </div>
      </div>
      Status
      <div class="uk-margin">
         <div class="uk-form-controls">
            <select class="uk-select" id="form-stacked-select" name="status">
               <option value="Publish">Publish</option>
               <option value="Not Publish">Not Publish</option>
            </select>
         </div>
      </div>
   </fieldset>
   <div class="uk-margin">
      <input  class="uk-button uk-button-default" type="submit" placeholder="Post">
</form>
</div>
<?php if(session()->has('message')): ?>
<script>UIkit.notification({message: 'Berhasil Di Update', pos: 'bottom-center'})</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>