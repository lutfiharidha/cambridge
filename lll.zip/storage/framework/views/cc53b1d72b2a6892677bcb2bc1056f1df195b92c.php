<?php $__env->startSection('content'); ?>
<div class="uk-container uk-container-medium uk-card uk-card-secondary" uk-scrollspy="cls: uk-animation-fade; repeat: true">
<form class="uk-padding " action="<?php echo e(route('update.package',$package)); ?>"  enctype="multipart/form-data" method="post">
   <fieldset class=" uk-margin-top uk-fieldset">
      <?php echo e(csrf_field()); ?>

      <?php echo e(method_field('PATCH')); ?>

      <legend class="uk-legend ">Edit Package</legend>
      Name
      <div class="uk-margin">
         <input class="uk-input" type="text" name="name" value="<?php echo e($package->name); ?>">
      </div>
      Description
      <div class="uk-margin">
         <textarea class="uk-textarea ckeditor" id="ckedtor" name="description" rows="5"><?php echo e($package->description); ?></textarea>
      </div>
      Price
      <div class="uk-margin">
         <input class="uk-input" type="number" name="price" value="<?php echo e($package->price); ?>">
      </div>
      <div class="uk-margin">
         <div class="uk-form-controls">
            <select class="uk-select" id="form-stacked-select" name="until">
               <?php if($package->until == "Week"): ?>
               <option value="<?php echo e($package->until); ?>"><?php echo e($package->until); ?></option>
                <option value="Month">Month</option>
               <option value="Year">Year</option>
               <?php elseif($package->until == "Month"): ?>
               <option value="<?php echo e($package->until); ?>"><?php echo e($package->until); ?></option>
               <option value="Week">Week</option>
               <option value="Year">Year</option>
               <?php else: ?>
               <option value="<?php echo e($package->until); ?>"><?php echo e($package->until); ?></option>
               <option value="Week">Week</option>
               <option value="Month">Month</option>
               <?php endif; ?>
            </select>
         </div>
      </div>
      Status
      <div class="uk-margin">
         <div class="uk-form-controls">
            <select class="uk-select" id="form-stacked-select" name="status">
               <?php if($package->status == "Publish"): ?>
               <option value="<?php echo e($package->status); ?>"><?php echo e($package->status); ?></option>
               <option value="Not Publish">Not Publish</option>
               <?php else: ?>
               <option value="<?php echo e($package->status); ?>"><?php echo e($package->status); ?></option>
               <option value="Publish">Publish</option>
               <?php endif; ?>
            </select>
         </div>
      </div>
   </fieldset>
   <div class="uk-margin">
      <input  class="uk-button uk-button-default" type="submit" placeholder="Post">
</form>
</div>
<?php if(session()->has('message')): ?>
<script>UIkit.notification({message: 'Berhasil Di Update', pos: 'bottom-center'})</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>