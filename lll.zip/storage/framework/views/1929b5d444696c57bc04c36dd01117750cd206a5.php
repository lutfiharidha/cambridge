<?php $__env->startSection('content'); ?>
<main class="uk-container uk-container-large" uk-height-viewport="offset-top: false">
   <div class="uk-container uk-container-large">
      <div class="uk-section">
         <div class="uk-container">
            <div  uk-grid>
               <div class=" uk-width-expand ">
                <div class="uk-child-width-1-3@s uk-grid-small" uk-grid>
                <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="#more" uk-toggle><img class="uk-border-rounded" width="350" height="350" src="/img/galleries/<?php echo e($gal->image); ?>" alt="<?php echo $gal->caption; ?>"></a>
                    <div id="more" uk-modal>
                        <div class="uk-border-rounded uk-modal-dialog uk-modal-body">
                            <button class="uk-modal-close-default" type="button" uk-close></button>
                            <h2 class="uk-modal-title uk-text-center uk-text-capitalize"><?php echo $gal->caption; ?></h2>
                            <img class="uk-border-rounded" src="/img/galleries/<?php echo e($gal->image); ?>" alt="<?php echo $gal->caption; ?>">
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                    </div>             
               </div>
               <div class=" uk-visible@m uk-width-1-3">
                  <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="uk-card uk-card-default uk-card-body uk-margin-bottom uk-width-1">
                     <h3 class="uk-card-title"><?php echo e($post1->title); ?></h3>
                     <p class="uk-text-justify"><?php echo str_limit($post1->post,100,' ...'); ?></p>
                     <a class="uk-label uk-button" href="<?php echo e(route('blog.action', [$post1->id, urlencode(date('Y', strtotime($post1->created_at))),preg_replace('/\+/', '-',urlencode(strtolower($post1->title)))])); ?>">Read more</a>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </div>
            </div>
         </div>
      </div>
   </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navb', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>