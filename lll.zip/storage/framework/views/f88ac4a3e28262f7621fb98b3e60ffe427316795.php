<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?></title>
    <!-- UIkit CSS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.0.0-rc.19/css/uikit.min.css" />

<!-- UIkit JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.0.0-rc.19/js/uikit.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.0.0-rc.19/js/uikit-icons.min.js"></script>
</head>
<body>
<div class="uk-background-fixed uk-background-cover uk-height-1 uk-panel uk-flex uk-flex-middle" uk-height-viewport="offset-bottom: false"  style="background-image: url(https://backgroundcheckall.com/wp-content/uploads/2017/12/background-login-5.png);">
    <div uk-scrollspy="cls: uk-animation-fade; repeat: false" class="uk-overlay uk-overlay-default uk-position-center uk-width-auto">
        <h1 class="uk-text-center">Cambridge School</h1>

            <form class="uk-align-center" method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
    <div class="uk-margin">
        <div class="uk-inline uk-width-expand">
            <span class="uk-form-icon" uk-icon="icon: user"></span>
            <input class="uk-input" type="email" name="email" required autofocus>
        </div>
    </div>

    <div class="uk-margin">
        <div class="uk-inline  uk-width-expand">
            <span class="uk-form-icon uk-form-icon-flip" uk-icon="icon: lock"></span>
            <input class="uk-input" type="password" name="password" required>
        </div>
    </div>
    <div class="uk-margin">
    <div class="uk-inline uk-float-right">
      <button class="uk-button uk-button-primary">Login</button>
    </div>
</div>
<?php if($errors->has('email')): ?>
      <div class="uk-text-danger">
         <?php echo e($errors->first('email')); ?>    
      </div>
      <?php endif; ?>
</form>
</div>
</div>
</body>
</html>

