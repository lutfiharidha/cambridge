<?php $__env->startSection('content'); ?>
    <h1 class="uk-text-center">Package</h1>
<div uk-scrollspy="cls: uk-animation-fade; repeat: false" class="uk-overlay uk-overlay-primary uk-width-auto">
   <table class="uk-table uk-table-divider">
      <thead>
         <tr>
         	<th>No</th>
          <th>Photo</th>
            <th>Name</th>
            <th>Description</th>
            <th>Class</th>
            <th>Year</th>
            <th>Status</th>
            <th>Action</th>
         </tr>
      </thead>
      <tbody>
         <?php $__currentLoopData = $stories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$story): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr>
            <td><?php echo e($stories->firstItem()+ $key); ?></td>
            <td><img width="80" height="80" class="uk-border-circle" src="/img/stories/<?php echo e($story->image); ?>"></td>
            <td><?php echo e($story->name); ?></td>
            <td><?php echo str_limit($story->post,200,' ...'); ?></td>
            <td><?php echo e($story->class); ?></td>
            <td><?php echo e($story->year); ?></td>
            <td><?php echo e($story->status); ?></td>
            <td>
               <a class="uk-button uk-button-text uk-text-primary" href="<?php echo e(route('update.stories',$story)); ?>">Update</a>
               <form action="<?php echo e(route('stories.destroy', $story)); ?>" method="post">
                  <?php echo e(csrf_field()); ?>

                  <?php echo e(method_field('DELETE')); ?>

                  <button class="uk-button uk-button-text uk-text-danger" onclick="return confirm('Are you sure to delete <?php echo e($story->name); ?>?')" > Delete </button>
               </form>
            </td>
         </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
   </table>
       <?php echo $stories->render(); ?>

</div>
<?php if(session()->has('message')): ?>
<div class="uk-text-center uk-text-lead" uk-alert>
    <a class="uk-alert-close" uk-close></a>
    <h3>Notice</h3>
    <p><?php echo e(session()->get('message')); ?></p>
</div>
      <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>