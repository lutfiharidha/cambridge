<?php $__env->startSection('content'); ?>
<div class="uk-padding uk-card uk-card-secondary" uk-scrollspy="cls: uk-animation-fade; repeat: true">
<form action="<?php echo e(route('update.teacher',$teacher)); ?>"  enctype="multipart/form-data" method="post">
   <fieldset class=" uk-margin-top uk-fieldset">
      <?php echo e(csrf_field()); ?>

      <?php echo e(method_field('PATCH')); ?>

      <legend class="uk-legend ">Posting</legend>
      <div class="uk-margin">
         Name
         <input class="uk-input" type="text" name="name" value="<?php echo e($teacher->name); ?>">
      </div>
      <div class="uk-margin">
         Email
         <input class="uk-input" type="text" name="email" value="<?php echo e($teacher->email); ?>">
      </div>
      <div class="uk-margin">
         Phone
         <input class="uk-input" type="text" name="phone" value="<?php echo e($teacher->phone); ?>">
      </div>
      <div class="uk-margin">
         Password
         <input class="uk-input" type="password" name="password">
      </div>
   </fieldset>
   <div class="uk-margin">
      <input  class="uk-button uk-button-default" type="submit" value="Post">
      <?php if($errors->has('email')): ?>
      <div class="uk-text-danger">
         <?php echo e($errors->first('email')); ?>    
      </div>
      <?php endif; ?>
      <?php if($errors->has('password')): ?>
      <div class="uk-text-danger">
         <?php echo e($errors->first('password')); ?>    
      </div>
      <?php endif; ?>
      <?php if(session()->has('message')): ?>
      <div class="uk-text-bold">
         <?php echo e(session()->get('message')); ?>

      </div>
      <?php endif; ?>
</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>