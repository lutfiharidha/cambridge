<?php $__env->startSection('title'); ?>
| <?php echo e($posts->title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('meta'); ?>
<?php echo e($posts->meta); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('meta'); ?>
<?php echo e($posts->keyword); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?> 
<div class="uk-card uk-card-default uk-card-body">
   <article class="uk-article">
      <h1 class="uk-article-title uk-text-center"><?php echo e($posts->title); ?></h1>
      <?php if($posts->file == ""): ?>
      <img class="uk-align-left uk-margin-remove-adjacent" src="https://www.freeiconspng.com/uploads/no-image-icon-4.png" width="225" height="150" alt="<?php echo e($posts->title); ?>">
      <?php elseif(in_array(substr($posts->file, -3), $image)): ?>
      <img class="uk-align-left uk-margin-remove-adjacent" src="/img/announcement/<?php echo e($posts->file); ?>" width="225" height="150" alt="<?php echo e($posts->title); ?>">
      <?php else: ?>
      <a href="/img/announcement/<?php echo e($posts->file); ?>" target="_blank">
         <img width="40" height="40" src="https://img.clipartxtras.com/43edbab99e6d1747643f6d8102cf06c2_new-file-simple-clip-art-at-clkercom-vector-clip-art-online-files-clipart-png_222-300.png" alt="<?php echo e($posts->file); ?>"><br><?php echo e($posts->file); ?>

      </a>
      <?php endif; ?>
      <p class="uk-article-meta">Written by <?php echo e($posts->writer); ?> on <?php echo e(date('d M Y', strtotime($posts->created_at))); ?>.</p>
      <p class="uk-text-lead uk-text-justify"><?php echo $posts->post; ?></p>
   </article>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>