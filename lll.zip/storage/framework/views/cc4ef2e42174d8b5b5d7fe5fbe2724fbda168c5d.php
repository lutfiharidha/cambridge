<?php $__env->startSection('content'); ?>
<h1 class="uk-text-center">Articles</h1>
   <?php $__currentLoopData = $article; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <div class="uk-overlay uk-overlay-secondary uk-card-body">
      <article class="uk-article">
         <h3><?php echo e($posts->title); ?></h3>
         <p class="uk-article-meta">Written by <?php echo e($posts->writer); ?> on <?php echo e(date('d M Y', strtotime($posts->created_at))); ?>.</p>
         <p><?php echo str_limit($posts->post,200,' ...'); ?></p>
         <div class="uk-grid-small uk-child-width-auto" uk-grid>
            <div>
               <a class="uk-button uk-button-text" href="<?php echo e(route('article.action', [$posts->id, urlencode(date('Y', strtotime($posts->created_at))),preg_replace('/\+/', '-',urlencode(strtolower($posts->title)))])); ?>">Read more</a>
            </div>
         </div>
      </article>
   </div>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <div class="uk-margin">
      <?php echo $article->render(); ?>

   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>