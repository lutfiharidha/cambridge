<?php $__env->startSection('content'); ?>
<h1 class="uk-text-center">Announcement</h1>
<div uk-scrollspy="cls: uk-animation-fade; repeat: false" class="uk-overlay uk-overlay-primary uk-width-auto ">
   <table class="uk-table uk-table-divider uk-table-responsive">
      <thead>
         <tr>
            <th>No</th>
            <th>Image</th>
            <th>Title</th>
            <th>Description</th>
            <th>Status</th>
            <th>Action</th>
         </tr>
      </thead>
      <tbody>
         <?php $__currentLoopData = $announcement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$announce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr>
            <td><?php echo e($announcement->firstItem()+ $key); ?></td>
            <td><?php if($announce->image == ""): ?>
               <img width="80" height="80" class="uk-border-circle" src="https://www.freeiconspng.com/uploads/no-image-icon-4.png">
               <?php elseif(in_array(substr($announce->image, -3), $image)): ?>
               <img width="80" height="80" src="/img/announcement/<?php echo e($announce->image); ?>">
               <?php else: ?>
               <a href="/img/announcement/<?php echo e($announce->image); ?>" target="_blank">
                  <img width="40" height="40" src="https://img.clipartxtras.com/43edbab99e6d1747643f6d8102cf06c2_new-file-simple-clip-art-at-clkercom-vector-clip-art-online-files-clipart-png_222-300.png" alt="<?php echo e($announce->image); ?>">
               </a>
            <?php endif; ?></td>
            <td><?php echo e($announce->title); ?></td>
            <td><?php echo str_limit($announce->post,100,' ...'); ?></td>
            <td><?php if($announce->forr == ""): ?> 
               <?php echo e($announce->status); ?> 
               <?php else: ?>
               <?php echo e($announce->status); ?> for <?php echo e($announce->forr); ?>

               <?php endif; ?>
            </td>
            <td>
               <a class="uk-button uk-button-text uk-text-primary" href="<?php echo e(route('update.announce',$announce)); ?>">Update</a>
               <form action="<?php echo e(route('announce.destroy', $announce)); ?>" method="post">
                  <?php echo e(csrf_field()); ?>

                  <?php echo e(method_field('DELETE')); ?>

                  <button class="uk-button uk-button-text uk-text-danger" onclick="return confirm('Are you sure to delete <?php echo e($announce->title); ?>?')" > Delete </button>
               </form>
            </td>
         </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
   </table>
   <?php echo $announcement->render(); ?>

</div>
<?php if(session()->has('message')): ?>
<div class="uk-text-center uk-text-lead" uk-alert>
   <a class="uk-alert-close" uk-close></a>
   <h3>Notice</h3>
   <p><?php echo e(session()->get('message')); ?></p>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>