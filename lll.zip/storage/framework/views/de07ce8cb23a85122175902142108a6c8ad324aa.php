<?php $__env->startSection('content'); ?>
<div uk-scrollspy="cls: uk-animation-fade; delay: 500; repeat: false">
    <h1 class="uk-text-center">Change Password</h1>
<form action="<?php echo e(route('password.update')); ?>" method="POST">
<?php echo e(csrf_field()); ?>

<div class="uk-card-secondary uk-overlay uk-overlay-primary">
<div class="uk-margin">
            <input class="uk-input" id="Password" name="old" type="password" placeholder="Current Password" required>
    </div>
    <div class="uk-margin">
            <input class="uk-input" id="Password" name="password" type="password" placeholder="New Password" required>
    </div>
    <div class="uk-margin">
            <input class="uk-input" id="password-confirm" name="password_confirmation" type="password" placeholder="Confirm New Password" required>
    </div>

    <div class="uk-margin">
        <button class="uk-button uk-button-default">Change</button>
        <?php if($errors->has('password_confirmation')): ?>
        <div class="uk-text-danger">
            <?php echo e($errors->first('password_confirmation')); ?>    
        </div>
        <?php endif; ?>
        <?php if($errors->has('password')): ?>
        <div class="uk-text-danger">
            <?php echo e($errors->first('password')); ?>    
        </div>
        <?php endif; ?>
        <?php if(session()->has('failure')): ?>
        <div class="uk-text-danger">
           <?php echo e(session()->get('failure')); ?>

        </div>
        <?php endif; ?>
        <?php if(session()->has('success')): ?>
        <div class="uk-text-bold">
           <?php echo e(session()->get('success')); ?>

        </div>
        <?php endif; ?>
    </div>
</div>
</form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>