<?php $__env->startSection('content'); ?>
<main class="uk-container uk-container-large" uk-height-viewport="offset-top: false">
   <div class="uk-container uk-container-large">
      <div class="uk-section">
         <div class="uk-container">
            <div  uk-grid>
               <div class=" uk-width-expand ">
               	<?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="uk-card uk-card-default uk-card-body">
                     <article class="uk-article">
                        <h3 class="uk-article-title"><?php echo e($posts->title); ?></h3>
                        <p class="uk-article-meta">Written by <?php echo e($posts->nama); ?> on <?php echo e(date('d M Y', strtotime($posts->created_at))); ?>.</p>
                        <p class="uk-text-lead"><?php echo str_limit($posts->post,200,' ...'); ?></p>
					    <div class="uk-grid-small uk-child-width-auto" uk-grid>
					        <div>
					            <a class="uk-button uk-button-text" href="<?php echo e(route('blog.action', [$posts->id, urlencode(date('Y', strtotime($posts->created_at))),preg_replace('/\+/', '-',urlencode(strtolower($posts->title)))])); ?>">Read more</a>
					        </div>
					    </div>
                     </article>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <div class="uk-margin">
               <?php echo $blog->render(); ?>

               </div>                  	
               </div>
               <div class=" uk-visible@m uk-width-1-3">
                  <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="uk-card uk-card-default uk-card-body uk-margin-bottom uk-width-1">
                     <h3 class="uk-card-title"><?php echo e($post1->title); ?></h3>
                     <p class="uk-text-justify"><?php echo str_limit($post1->post,100,' ...'); ?></p>
                     <a class="uk-label uk-button" href="<?php echo e(route('blog.action', [$post1->id, urlencode(date('Y', strtotime($post1->created_at))),preg_replace('/\+/', '-',urlencode(strtolower($post1->title)))])); ?>">Read more</a>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </div>
            </div>
         </div>
      </div>
   </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navb', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>