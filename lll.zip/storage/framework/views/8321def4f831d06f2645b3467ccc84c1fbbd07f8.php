<?php $__env->startSection('content'); ?>
<div class="uk-container uk-container-medium uk-card uk-card-secondary" uk-scrollspy="cls: uk-animation-fade; repeat: true">
<form class="uk-padding " action="<?php echo e(route('update.announce',$announce)); ?>"  enctype="multipart/form-data" method="post">
   <fieldset class=" uk-margin-top uk-fieldset">
      <?php echo e(csrf_field()); ?>

      <?php echo e(method_field('PATCH')); ?>

      <legend class="uk-legend ">Edit Announcement</legend>
      Title
      <div class="uk-margin">
         <input class="uk-input" type="text" name="title" value="<?php echo e($announce->title); ?>" required>
      </div>
            Image
      <div class="uk-margin">
         <div uk-form-custom>
            <?php if($announce->image == ""): ?>
               <img width="80" height="80" class="uk-border-circle" src="https://www.freeiconspng.com/uploads/no-image-icon-4.png">
               <?php elseif(in_array(substr($announce->image, -3), $image)): ?>
               <img width="80" height="80" src="/img/announcement/<?php echo e($announce->image); ?>">
               <?php else: ?>
               <a href="/img/announcement/<?php echo e($announce->image); ?>" target="_blank">
                  <img width="40" height="40" src="https://img.clipartxtras.com/43edbab99e6d1747643f6d8102cf06c2_new-file-simple-clip-art-at-clkercom-vector-clip-art-online-files-clipart-png_222-300.png" alt="<?php echo e($announce->image); ?>">
               </a>
            <?php endif; ?>
            <input type="file" name="file">
            <button class="uk-button uk-button-default" type="button" tabindex="-1">Select</button>
         </div>
      </div>
      Description
      <div class="uk-margin">
         <textarea class="uk-textarea ckeditor" id="ckedtor" name="description" rows="5"><?php echo $announce->post; ?></textarea>
      </div>
             <script type="text/javascript">
         var editor = CKEDITOR.replace( 'ckedtor', {
    language: 'en',
    extraPlugins: 'notification'
});

editor.on( 'required', function( evt ) {
    editor.showNotification( 'This field is required.', 'warning' );
    evt.cancel();
} );
</script>
      Status
      <div class="uk-margin">
         <div class="uk-form-controls">
            <select class="uk-select uk-form-width-medium" id="form-stacked-select" name="status">
               <?php if($announce->status == "Publish"): ?>
               <option value="<?php echo e($announce->status); ?>"><?php echo e($announce->status); ?></option>
               <option value="Not Publish">Not Publish</option>
               <?php else: ?>
               <option value="<?php echo e($announce->status); ?>"><?php echo e($announce->status); ?></option>
               <option value="Publish">Publish</option>
               <?php endif; ?>
            </select>
         </div>
         <div class="uk-margin">
            <?php if($announce->status == "Publish"): ?>
            <div id="sel" class="uk-form-controls">
               <select class="uk-select uk-form-width-medium" name="forr">
                  <?php if($announce->forr == "Everyone"): ?>   
                  <option value="<?php echo e($announce->forr); ?>"><?php echo e($announce->forr); ?></option>
                  <option value="Student">Student</option>
                  <option value="Teacher">Teacher</option>
                  <?php elseif($announce->forr == "Student"): ?>
                  <option value="<?php echo e($announce->forr); ?>"><?php echo e($announce->forr); ?></option>
                  <option value="Everyone">Everyone</option>
                  <option value="Teacher">Teacher</option>
                  <?php else: ?>
                  <option value="<?php echo e($announce->forr); ?>"><?php echo e($announce->forr); ?></option>
                  <option value="Student">Student</option>
                  <option value="Everyone">Everyone</option>                  
                  <?php endif; ?>
               </select>
               <?php endif; ?>
            </div>
            <p></p>
         </div>
         <div class="uk-margin">
            <input  class="uk-button uk-button-default" type="submit" value="Post">
         </div>
         <script>
            $(document).ready(function () {
                $("#form-stacked-select").change(function () {
                    var foo = $("#form-stacked-select").val();
                    if (foo == "Not Publish") {
                        $("div#sel").empty()
                     }
                    else{
                    $("p").html("<div id='sel'><select class='uk-select uk-form-width-medium' name='forr'><option value='Everyone'>Everyone</option><option value='Student'>Student</option><option value='Teacher'>Teacher</option></select>")
                    }
                });
            });
         </script>
   </fieldset>
</form>
</div>
<?php if($errors->any()): ?>
<div class="uk-text-center uk-text-lead" uk-alert>
   <a class="uk-alert-close" uk-close></a>
   <h3>Notice</h3>
   <?php echo e(implode('', $errors->all(':message'))); ?>

</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>