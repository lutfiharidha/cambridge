<?php $__env->startSection('content'); ?>
<?php if(session()->has('popup')): ?>
<script type="text/javascript">
           UIkit.modal.alert('<h3 class="uk-text-center">WELCOME BACK <span class="uk-text-uppercase"><?php echo e(Auth::user()->name); ?></span></h3>').then(function () {
               console.log('Alert closed.')
           });
</script>
<?php endif; ?>
<div class="uk-text-center uk-child-width-1-4@s uk-grid-small" uk-grid>
    <div>
        <h2>User <span class="uk-badge"><?php echo e($datauser); ?></span></h2>
        <div class="uk-padding">
            <h5>Admin : <span class="uk-badge"><?php echo e($dataadmin); ?></span></h5>
            <h5>Teacher : <span class="uk-badge"><?php echo e($datateacher); ?></span></h5>
            <h5>Student : <span class="uk-badge"><?php echo e($datastudent); ?></span></h5>
        </div>
    </div>
    <div>
        <h2>Blog <span class="uk-badge"><?php echo e($datablog); ?></span></h2>
        <div class="uk-padding">
            <h5>Publish : <span class="uk-badge"><?php echo e($pdatablog); ?></span></h5>
            <h5>Unpublish : <span class="uk-badge"><?php echo e($udatablog); ?></span></h5>
        </div>
    </div>
    <div>
        <h2>Gallery <span class="uk-badge"><?php echo e($datagallery); ?></span></h2>
        <div class="uk-padding">
            <h5>Publish : <span class="uk-badge"><?php echo e($pdatagallery); ?></span></h5>
            <h5>Unpublish : <span class="uk-badge"><?php echo e($udatagallery); ?></span></h5>
        </div>
    </div>
    <div>
        <h2>Stories <span class="uk-badge"><?php echo e($datastory); ?></span></h2>
        <div class="uk-padding">
            <h5>Publish : <span class="uk-badge"><?php echo e($pdatastory); ?></span></h5>
            <h5>Unpublish : <span class="uk-badge"><?php echo e($udatastory); ?></span></h5>
        </div>
    </div>
    <div>
        <h2>Packages <span class="uk-badge"><?php echo e($datapackage); ?></span></h2>
        <div class="uk-padding">
            <h5>Publish : <span class="uk-badge"><?php echo e($pdatapackage); ?></span></h5>
            <h5>Unpublish : <span class="uk-badge"><?php echo e($udatapackage); ?></span></h5>
        </div>
    </div>
    <div>
        <h2>Announcement <span class="uk-badge"><?php echo e($dataannounce); ?></span></h2>
        <div class="uk-padding">
            <h5>Publish : <span class="uk-badge"><?php echo e($pdataannounce); ?></span></h5>           
            <h5>Unpublish : <span class="uk-badge"><?php echo e($udataannounce); ?></span></h5>
        </div>
    </div>
    <div>
        <h2>Module <span class="uk-badge"><?php echo e($datamodule); ?></span></h2>
        <div class="uk-padding">
            <h5>Publish : <span class="uk-badge"><?php echo e($pdatamodule); ?></span></h5>
            <h5>Unpublish : <span class="uk-badge"><?php echo e($udatamodule); ?></span></h5>
        </div>
    </div>
    <div>
        <h2>Article <span class="uk-badge"><?php echo e($dataarticle); ?></span></h2>
        <div class="uk-padding">
            <h5>Publish : <span class="uk-badge"><?php echo e($pdataarticle); ?></span></h5>
            <h5>Unpublish : <span class="uk-badge"><?php echo e($udataarticle); ?></span></h5>
        </div>
    </div>
</div>
<div class="uk-text-center">
        <h2>Orders <span class="uk-badge"><?php echo e($dataorder); ?></span></h2>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>