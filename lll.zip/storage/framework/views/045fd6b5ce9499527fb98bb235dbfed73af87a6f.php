 
<?php $__env->startSection('content'); ?>
<div class="uk-container uk-container-medium uk-card uk-card-secondary" uk-scrollspy="cls: uk-animation-fade; repeat: true">
   <form class="uk-padding" action="<?php echo e(route('update.gallery',$gallery)); ?>"  enctype="multipart/form-data" method="post">
      <fieldset class=" uk-margin-top uk-fieldset">
          <?php echo e(csrf_field()); ?>

          <?php echo e(method_field('PATCH')); ?>

        <legend class="uk-legend ">Edit Gallery</legend>
         Image
         <div class="uk-margin">
            <div uk-form-custom>
            	<img width="150" height="150" src="/img/galleries/<?php echo e($gallery->image); ?>">
               <input type="file" name="image">
               <button class="uk-button uk-button-default" type="button" tabindex="-1">Select</button>
            </div>
         </div>
         Caption
         <div class="uk-margin">
            <textarea class="uk-textarea ckeditor" id="ckedtor" name="caption" rows="5"><?php echo $gallery->caption; ?></textarea>
         </div>
         <script type="text/javascript">
         var editor = CKEDITOR.replace( 'ckedtor', {
    language: 'en',
    extraPlugins: 'notification'
});

editor.on( 'required', function( evt ) {
    editor.showNotification( 'This field is required.', 'warning' );
    evt.cancel();
} );
</script>
         Status
      <div class="uk-margin">
         <div class="uk-form-controls">
            <select class="uk-select uk-form-width-medium" id="form-stacked-select" name="status">
               <?php if($gallery->status == "Publish"): ?>
               <option value="<?php echo e($gallery->status); ?>"><?php echo e($gallery->status); ?></option>
               <option value="Not Publish">Not Publish</option>
               <?php else: ?>
               <option value="<?php echo e($gallery->status); ?>"><?php echo e($gallery->status); ?></option>
               <option value="Publish">Publish</option>
               <?php endif; ?>
            </select>
         </div>
     </div>
      </fieldset>
      <div class="uk-margin">
         <input  class="uk-button uk-button-default" type="submit" placeholder="Post">
      </div>
   </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>