<?php $__env->startSection('content'); ?>
<div class="uk-padding uk-container uk-container-small uk-dark" uk-scrollspy="cls: uk-animation-fade; delay: 500; repeat: false">
    <h1 class="uk-text-center">Order <?php echo e($posts->name); ?></h1>
<form action="<?php echo e(route('order.store')); ?>" method="POST">
<?php echo e(csrf_field()); ?>

<div class="uk-card-secondary uk-overlay uk-overlay-primary">
    <div class="uk-margin">
            <input class="uk-input" id="inputName" name="name" type="text" placeholder="Name" required>
    </div>
    <div class="uk-margin">
            <input class="uk-input" name="address" type="text" placeholder="Address" required>
    </div>
    <div class="uk-margin">
            <input class="uk-input" name="phone" type="number" placeholder="Phone Number" required>
    </div>
    <div class="uk-margin">
            <input class="uk-input" name="wa" type="number" placeholder="WhatsApp">
    </div>
    <div class="uk-margin">
            <input class="uk-input" name="package" type="hidden" value="<?php echo e($posts->id); ?>" >
            <input class="uk-input" type="text" value="<?php echo e($posts->name); ?>" disabled>
    </div>
    <div class="uk-margin">
        <button class="uk-button uk-button-default">Order</button>
    </div>
</div>
</form>
<?php if(session()->has('message')): ?>
<script type="text/javascript">
    UIkit.modal.dialog('<h1 class="uk-text-center uk-modal-body"><?php echo e(session()->get("message")); ?></h1>');
</script>
<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navb', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>