<?php $__env->startSection('content'); ?>
<h1 class="uk-text-center">Blog</h1>
<div uk-scrollspy="cls: uk-animation-fade; repeat: false" class="uk-overlay uk-overlay-primary uk-width-auto">
   <table class="uk-table uk-table-divider">
      <thead>
         <tr>
            <th>No</th>
            <th>Title</th>
            <th>File</th>
            <th>Uploader</th>
            <th>Status</th>
            <th>Action</th>
         </tr>
      </thead>
      <tbody>
         <?php $__currentLoopData = $module; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$modul): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($modul->title); ?></td>
            <td><a href="/files/<?php echo e($modul->file); ?>" target="_blank"><img width="40" height="40" src="https://img.clipartxtras.com/43edbab99e6d1747643f6d8102cf06c2_new-file-simple-clip-art-at-clkercom-vector-clip-art-online-files-clipart-png_222-300.png" alt="<?php echo e($modul->file); ?>"></a></td>
            <td><?php echo e($modul->uploader); ?></td>
            <td><?php echo e($modul->status); ?></td>
            <td>
               <form action="<?php echo e(route('module.destroymin', $modul)); ?>" method="post">
                  <?php echo e(csrf_field()); ?>

                  <?php echo e(method_field('DELETE')); ?>

                  <button class="uk-button uk-button-text uk-text-danger" onclick="return confirm('Are you sure to delete <?php echo e($modul->title); ?>?')" >Delete</button>
               </form>
            </td>
         </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
   </table>
<?php echo e($module->links()); ?></div>
<?php if(session()->has('message')): ?>
<div class="uk-text-center uk-text-lead" uk-alert>
   <a class="uk-alert-close" uk-close></a>
   <h3>Notice</h3>
   <p><?php echo e(session()->get('message')); ?></p>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>