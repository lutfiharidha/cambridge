<?php $__env->startSection('content'); ?>
<div class="uk-container uk-container-small uk-padding">
	<?php $__currentLoopData = $announcement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $announce): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h3 class="uk-text-uppercase"><?php echo e($announce->title); ?></h3>
            <div class="uk-panel">
            	<?php if($announce->image == ""): ?>
              <img class="uk-align-left uk-margin-remove-adjacent" src="https://www.freeiconspng.com/uploads/no-image-icon-4.png" width="225" height="150" alt="<?php echo e($announce->title); ?>">
               <?php elseif(in_array(substr($announce->image, -3), $image)): ?>
               <img class="uk-align-left uk-margin-remove-adjacent" src="/img/announcement/<?php echo e($announce->image); ?>" width="225" height="150" alt="<?php echo e($announce->title); ?>">
               <?php else: ?>
               <a href="/img/announcement/<?php echo e($announce->image); ?>" target="_blank">
                  <img width="40" height="40" src="https://img.clipartxtras.com/43edbab99e6d1747643f6d8102cf06c2_new-file-simple-clip-art-at-clkercom-vector-clip-art-online-files-clipart-png_222-300.png" alt="<?php echo e($announce->image); ?>"><br><?php echo e($announce->image); ?>

               </a>
            <?php endif; ?>
    			<?php echo $announce->post; ?>

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       <?php echo $announcement->render(); ?>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navb', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>