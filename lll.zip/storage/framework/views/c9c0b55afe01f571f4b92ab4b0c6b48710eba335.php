<?php $__env->startSection('content'); ?>
<?php if(session()->has('popup')): ?>
<script type="text/javascript">
           UIkit.modal.alert('<h3 class="uk-text-center">WELCOME BACK <span class="uk-text-uppercase"><?php echo e(Auth::user()->name); ?></span></h3><?php if($dataannounce !== 0): ?><p class="uk-text-center">You Have <span class="uk-text-bold"><?php echo e($dataannounce); ?></span> Announcement <?php else: ?> You do not have Announcement</p> <?php endif; ?>').then(function () {
               console.log('Alert closed.')
           });
</script>
<?php endif; ?>
<div class="uk-text-center uk-child-width-1-3@s uk-grid-small" uk-grid>
	<div>
        <h2>Blog <span class="uk-badge"><?php echo e($datablog); ?></span></h2>
        <div class="uk-padding">
            <h5>Publish : <span class="uk-badge"><?php echo e($pdatablog); ?></span></h5>
            <h5>Unpublish : <span class="uk-badge"><?php echo e($udatablog); ?></span></h5>
        </div>
    </div>
    <div>
        <h2>Module <span class="uk-badge"><?php echo e($datamodule); ?></span></h2>
        <div class="uk-padding">
            <h5>Publish : <span class="uk-badge"><?php echo e($pdatamodule); ?></span></h5>
            <h5>Unpublish : <span class="uk-badge"><?php echo e($udatamodule); ?></span></h5>
        </div>
    </div>
    <div>
        <h2>Article <span class="uk-badge"><?php echo e($dataarticle); ?></span></h2>
        <div class="uk-padding">
            <h5>Publish : <span class="uk-badge"><?php echo e($pdataarticle); ?></span></h5>
            <h5>Unpublish : <span class="uk-badge"><?php echo e($udataarticle); ?></span></h5>
        </div>
    </div>
</div>
<ul uk-accordion>
    <?php $__currentLoopData = $announce; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $annon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li>
        <a class="uk-accordion-title" href="#"><?php echo e($annon->title); ?> <span class="uk-float-right uk-badge"><?php echo e(date('d-m-Y', strtotime($annon->created_at))); ?></span></a>
        <div class="uk-accordion-content">
            <?php if($annon->image == ""): ?>
              <img class="uk-align-left uk-margin-remove-adjacent" src="https://www.freeiconspng.com/uploads/no-image-icon-4.png" width="225" height="150" alt="<?php echo e($annon->title); ?>">
               <?php elseif(in_array(substr($annon->image, -3), $image)): ?>
               <img class="uk-align-left uk-margin-remove-adjacent" src="/img/announcement/<?php echo e($annon->image); ?>" width="225" height="150" alt="<?php echo e($annon->title); ?>">
               <?php else: ?>
               <a href="/img/announcement/<?php echo e($annon->image); ?>" target="_blank">
                  <img width="40" height="40" src="https://img.clipartxtras.com/43edbab99e6d1747643f6d8102cf06c2_new-file-simple-clip-art-at-clkercom-vector-clip-art-online-files-clipart-png_222-300.png" alt="<?php echo e($annon->image); ?>"><br><?php echo e($annon->image); ?>

               </a>
            <?php endif; ?>
            <p><?php echo $annon->post; ?></p>
        </div>
    </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php echo $announce->render(); ?>

<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>