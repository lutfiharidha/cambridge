<?php $__env->startSection('content'); ?>
<h1 class="uk-text-center">Blog</h1>
<div uk-scrollspy="cls: uk-animation-fade; repeat: false" class="uk-overlay uk-overlay-primary uk-width-auto">
   <table class="uk-table uk-table-divider">
      <thead>
         <tr>
            <th>No</th>
            <th>Image</th>
            <th>Title</th>
            <th>Description</th>
            <th>Writer</th>
            <th>Status</th>
            <th>Action</th>
         </tr>
      </thead>
      <tbody>
         <?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr>
<td><?php echo e($loop->iteration); ?></td>
            <td><img width="80" height="80" src="/img/blogs/<?php echo e($post->image); ?>"></td>
            <td><?php echo e($post->title); ?></td>
            <td><?php echo str_limit($post->post,100,' ...'); ?></td>
            <td><?php echo e($post->writer); ?></td>
            <td><?php echo e($post->status); ?></td>
            <td>
               <a class="uk-button uk-button-text uk-text-primary" href="<?php echo e(route('update.blog',$post)); ?>">Update</a>
               <form action="<?php echo e(route('blog.destroy', $post)); ?>" method="post">
                  <?php echo e(csrf_field()); ?>

                  <?php echo e(method_field('DELETE')); ?>

                  <button class="uk-button uk-button-text uk-text-danger" onclick="return confirm('Are you sure to delete <?php echo e($post->title); ?>?')" > Delete </button>
               </form>
            </td>
         </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
   </table>
<?php echo e($blog->links()); ?></div>
<?php if(session()->has('message')): ?>
<div class="uk-text-center uk-text-lead" uk-alert>
   <a class="uk-alert-close" uk-close></a>
   <h3>Notice</h3>
   <p><?php echo e(session()->get('message')); ?></p>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>