<?php $__env->startSection('title'); ?>
| <?php echo e($posts->title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('meta'); ?>
<?php echo e($posts->meta); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('meta'); ?>
<?php echo e($posts->keyword); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?> 
<main id="main" class="uk-container uk-container-large uk-margin-top uk-margin-bottom" uk-height-viewport="offset-top: false">
   <div class="uk-container uk-container-large">
      <div class="uk-section">
         <div class="uk-container">
            <div  uk-grid>
               <div class=" uk-width-expand ">
                  <div class="uk-card uk-card-default uk-card-body">
                     <article class="uk-article">
                        <h1 class="uk-article-title uk-text-center"><?php echo e($posts->title); ?></h1>
                        <center><img width="500" height="500" class="uk-margin-small-bottom"  src="/img/stories/<?php echo e($posts->image); ?>" alt="<?php echo e($posts->title); ?>"></center>
                        <p class="uk-article-meta">Written by <?php echo e($posts->writer); ?> on <?php echo e(date('d M Y', strtotime($posts->created_at))); ?>.</p>
                        <p class="uk-text-lead uk-text-justify"><?php echo $posts->post; ?></p>
                     </article>
                  </div>
                  <div id="top"></div>
               </div>
               <div class=" uk-visible@m uk-width-1-3">
                  <?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="uk-card uk-card-default uk-card-body uk-margin-bottom uk-width-1">
                     <h3 class="uk-card-title"><?php echo e($post1->title); ?></h3>
                     <p class="uk-text-justify"><?php echo str_limit($post1->post,100,' ...'); ?></p>
                     <a class="uk-label uk-button" href="<?php echo e(route('blog.action', [$post1->id, urlencode(date('Y', strtotime($post1->created_at))),preg_replace('/\+/', '-',urlencode(strtolower($post1->title)))])); ?>">Read more</a>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </div>
            </div>
         </div>
      </div>
   </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.navb', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>