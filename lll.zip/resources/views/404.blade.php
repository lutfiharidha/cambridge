@extends('layouts.navb')
@section('content')
<main class="uk-padding uk-container uk-container-large">
	<div>
	<img class="uk-align-center" src="http://frugalz.com/assets/front/images/404.png">
	</div>
</main>
@endsection